package com.lab3.zad1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zad1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
